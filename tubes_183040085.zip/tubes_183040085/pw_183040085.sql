-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2019 at 04:12 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pw_183040085`
--

-- --------------------------------------------------------

--
-- Table structure for table `elektronik`
--

CREATE TABLE `elektronik` (
  `id` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `gambar` varchar(90) NOT NULL,
  `fungsi` varchar(40) NOT NULL,
  `merk` varchar(30) NOT NULL,
  `harga` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elektronik`
--

INSERT INTO `elektronik` (`id`, `nama`, `gambar`, `fungsi`, `merk`, `harga`) VALUES
(1, 'Laptop', '1.jpg', 'menyelesaikan tugas dgn flexibel', 'HP Spectre X360', 'Rp24.499.000'),
(2, 'Televisi', '2.jpg', 'menyampaikan informasi dan hiburan ', 'Samsung 43in', 'Rp 4.244.000'),
(3, 'Mesin Cuci', '3.jpg', 'untuk mencuci &amp; mengeringkan ', 'Sharp ES-FL862', 'Rp 3.088.800'),
(4, 'Kulkas', '4.jpg', 'untuk mendinginkan bahan-bahan makanan', 'Sharp SJ-IF85PB-SL', 'Rp 13.250.800'),
(5, 'Setrika', '5.jpg', 'untuk untuk melicinkan pakaian', 'Philips GC160/27', 'Rp 249.123'),
(6, 'DVD Player', '6.jpg', 'Alat Elektronik untuk memutar cd', 'Kirin KEF-16SFE', 'Rp 284.833'),
(7, 'Kipas Angin', '7.jpg', 'Alat Elektronik untuk menyejukan suasana', 'Kirin KEF-16SFE', 'Rp 284.833'),
(8, 'Microwave', '8.jpg', 'untuk menghangatkan makan', 'Maspion MOT500E', 'Rp 229.000'),
(9, 'Penghisap Debu', '9.jpg', 'untuk membersihkan debu &amp; kotoran ', 'Sharp EC-8305', 'Rp 648.000'),
(10, 'AC', '10.jpg', 'untuk mendinginkan ruangan', 'LG T05NLA', ' Rp 2.420.000'),
(18, 'nnnn', '5ccfae3bca68a.jpg', 'menymasi dan hiburan melalui gamba', 'dfghjkl', '   '),
(27, '', '5ccfa6c0957db.jpg', 'wkwkwk', 'hiyaaa', '000$');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(16) NOT NULL,
  `password` varchar(32) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'admin', 'admin', '2019-04-26 03:38:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `elektronik`
--
ALTER TABLE `elektronik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `elektronik`
--
ALTER TABLE `elektronik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
