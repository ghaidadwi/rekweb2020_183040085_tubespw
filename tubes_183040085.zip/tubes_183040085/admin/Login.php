<?php
session_start();
$_SESSION["username"]="admin";
$_SESSION["password"]="admin";
if (isset($_POST["login"])){
    if ($_POST["username"]=="admin" && $_POST["password"]=="admin"){
        header("location:index.php");
    }else{
     		$error=true;
    }
}
?>

<!DOCTYPE html>
  <html>
    <head>
    	<title>Halaman Login Admin</title>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <style>
		body{
				background-color:#EF9835;
				color: #333;
				background-image: url(../assets/img/dapur.png); 
			}
		.container{
			width: 380px;
		}
		h3{
			text-align: center;
			font-family: Ink Free;
			font-weight: bolder;
			font-size: 30px;
		}
		img{
			
			width: 90px;
			display: block;
			margin: auto;
		}
		p{
			text-align: center;
			font-family: Ink Free;
			font-weight: bolder;
			font-size: 15px;
		}

	</style>
    </head>

    <body>
    	<!-- Login -->
    	<div class="container">
	    	<div class="row">
	    		<div class="card-panel #eeeeee grey lighten-3">
			    		<h3>Login Admin</h3>
					<?php if(isset($error)) { ?>
						<p>Maaf username anda salah</p>
					<?php } ?>
			    		<img src="password.png">
							<br>
						  <form action="" method="post">
							   <div class="row">
							        <div class="input-field col s12">
							          <i class="material-icons prefix">account_circle</i>
							          <input id="icon_prefix" type="text" class="validate" name="username">
							          <label for="icon_prefix">Username</label>
							        </div>

							        <div class="input-field col s12">
							          <i class="material-icons prefix">lock_open</i>
							          <input id="icon_telephone" type="password" class="validate" name="password">
							          <label for="icon_telephone">Password</label>
							        </div>

							        <div class="input-field col s6 offset-s8">
							        	<input class="waves-effect waves-light btn brown lighten-2" type="submit" name="login" value="Login" style="background-color: Aquamarine  ;" />
							       </div>
							    </div>
						 </form>
					</div>
				  </div>
			</div>
    	<!-- Tutup Login -->



      <!--JavaScript at end of body for optimized loading-->
      <script type="text/javascript" src="../js/materialize.min.js"></script>
    </body>
  </html>

