<?php 

require '../functions.php';

if (isset($_GET['cari'])) {
		$keyword = $_GET['search'];
		$elektronik = query("SELECT * FROM elektronik WHERE
			nama LIKE '%$keyword%' OR
			gambar LIKE '%$keyword%' OR
			fungsi LIKE '%keyword%' OR
			merk LIKE '%$keyword%' OR
			harga LIKE '%$keyword%' ");
	} else {
$elektronik = query("SELECT * FROM elektronik");

}

 ?>


 <!DOCTYPE html>
  <html>
    <head>
    	<title>Halaman Admin</title>
 	<style>

 		body{
			background-color:#EF9835;
			color: #333;
			background-image: url(../assets/img/dapur.png); 
		}
 		.container{
			border-radius: 10px;
			background-color: #d7ccc8;
			border: 1px solid #d7ccc8;
			box-shadow: 10px 10px 10px ;
			text-align: center;
			font-family: Ink Free;
			font-weight: bolder;
			font-size: 15px;
		
		}

		.gambar {
			width: 100px;
			height: 100px;
		}
		a {
			text-align: center;
			/*top: 500px;*/
			text-decoration: none;
			color: #2F4F4F;
			font-weight: bolder;
			padding: 9px;
			background-color:  PeachPuff;
			border-radius: 10px;
			display: inline-table;
			
		}
		h1 {
			text-align: center;
			font-family: Ink Free;
			font-weight: bolder;
			font-size: 15px;
		}

		footer {
		padding: 20px 0px;
		}

		nav{
			font-family: Ink Free;
			font-weight: bolder;
			font-size: 15px;
		}

		
		
</style>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

    <body>

    	<!-- Navbar -->
    	<div class="navbar-fixed">
	      <nav class="#d7ccc8 brown lighten-3">
	        
	         <div class="nav-wrapper">
	          <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
		           
		            <ul class="right hide-on-med-and-down">

	            		<li><a href="../index.php"  class="logout" class="waves-effect waves-light btn" ><i class="material-icons right">desktop_mac</i>Logout</a></li>
	           		 </ul>

	           		 <ul  class="left hide-on-med-and-down" >
		           	<li>	
		         		 <a href="../tambah.php" >Tambah Data</a>
		         	</li>

		     
		         	</ul>

			            <ul class="brand-logo center">
			            	<li>	
			            	<form action="" method="get" >
			            	<i class="material-icons left">search
							<input  auto;" type="search" name="search" id="search" class="form-control" placeholder="Search..."></i>
							<button style="display: none;" type="submit" name="cari" id="cari" >cari</button>
							
							</form>
							</li>
						</ul>
            
		          </div>
		        
		      </nav>
		      </div>
    	<!-- TUTUP Navbar -->
    	

    	<h1>Macam Macam Alat Elektronik</h1>
	 	<br>
    	<div class="container">
	    	
	 		

			<table border="1" cellpadding="10" cellspacing="0" class="responsive-table">
						<tr>
							
							<th>No</th>
							<th align="center"> Opsi </th>
							<th>Nama Alat Elektronik</th>
							<th>Gambar</th>
							<th>Fungsi</th>
							<th>Merk</th>
							<th>Harga</th>
						</tr>
						<?php if (empty($elektronik)) :?>
							 	<tr>
							 		<td colspan="8">
							 			<h1 align="center" class="data">Data Tidak Ditemukan!</h1>
							 		</td>
							 	</tr>
							 <?php else : ?>


						<?php $i = 1; ?>
						<?php foreach ($elektronik as $alat) : ?>

							
						<tr>
						<td><?= $i; ?></td>
						<td>
							
						<a href="../ubah.php?id=<?=$alat['id']; ?>"><i class="material-icons">border_color</i></a>
						 |
						<a href="../hapus.php?id=<?=$alat['id']; ?>" onclick="return confirm('Anda yakin ingin menghapus?')"><i class="material-icons">delete_sweep</i></a>
							
						</td>
			 			<td><?php echo $alat["nama"]; ?></td>
			 			<td><img class ="gambar"src="../assets/img/<?php echo $alat["gambar"]; ?>"></td>
			 			<td><?php echo $alat["fungsi"]; ?></td>
			 			<td><?php echo $alat["merk"]; ?></td>
			 			<td><?php echo $alat["harga"]; ?></td>
						</tr>
						<?php $i++; ?>
						<?php endforeach; ?>
						<?php endif ?>
					</table>
				</div>
				<br>

			<!-- footer -->
				 <footer class="#d7ccc8 brown lighten-3 white-text center">
					<p class="flow-text">Ghaida Dwi Febriyanti. &copy right 2019</p>
				</footer>
			<!-- Tutup Footer -->


      <!--JavaScript at end of body for optimized loading-->
      <script type="text/javascript" src="../js/materialize.min.js"></script>
    </body>
  </html>

 <!DOCTYPE html>
 <html>
 <head>
 	
 </head>
 <body>
 
	

 
 </body>
 </html>