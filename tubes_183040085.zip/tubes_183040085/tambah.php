<?php 

require 'functions.php';
if (isset($_POST['submit'])) {
	if (tambah($_POST) > 0) {
		echo "<script>
			alert('Data Berhasil Ditambahkan!');
			document.location.href = 'admin/index.php';
		</script>";
	} else {
		echo "<script>
			alert('Data Gagal Ditambahkan!');
		</script>";
	}
	
}
 ?>

 <!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title>Tambah Alat Elektronik</title>
      <style>
 		body{
				background-color:#EF9835;
				color: #333;
				background-image: url(assets/img/dapur.png); 
			}

 		.container{
			font-family: Ink Free;
			font-weight: bold;

		}
 	</style>
    </head>

    <body>
    	<div class="container">	
	 		
	 			<div class="row">

		    		<div class="card-panel #eeeeee grey lighten-3">
		    			<h2>Tambah Alat Elektronik</h2>
				 			<form action="" method="post" enctype="multipart/form-data">
				 				 <div class="row">
					 				<div class="input-field col s12">
								 		<label for="nama">Nama Alat Elektronik</label>
								 		<input type="text" name="nama" id="nama" autofocus="on">
							 		</div>
						 		

						 		<div class="input-field col s12">
								 		
									 		<label for="gambar">Gambar</label><br>
									 		<br><input type="file" name="gambar" id="gambar" >
								 
							     </div>
							 		
							 		<div class="input-field col s12">
								 		<label for="fungsi">Fungsi</label>
					
								 		<input type="text" name="fungsi" id="fungsi">
							 		</div>
						 		

						 		
							 		<div class="input-field col s12">
								 		<label for="merk">Merk</label>
					
								 		<input type="text" name="merk" id="merk">
							 		</div>
						 		
						 		
							 		<div class="input-field col s12">
								 		<label for="harga">Harga</label>
					
								 		<input type="text" name="harga" id="harga">
							 		</div>
						 		

						 		
							 		<div class="input-field col s12">
								 		<button type="submit" name="submit" id="submit" class="waves-effect waves-light btn brown lighten-2">
								 			Tambah Data
								 		</button>
								 		<a href="admin/index.php" class="waves-effect waves-light btn brown lighten-2">
								 			kembali
								 		</a>
							 		</div>
						 		</div>
				 			</form>
			 		</div>
			 	</div>
 	
 </div>

      <!--JavaScript at end of body for optimized loading-->
      <script type="text/javascript" src="js/materialize.min.js"></script>

    </body>
  </html>




