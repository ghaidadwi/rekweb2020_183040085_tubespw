<?php 
require 'functions.php';
$id = $_GET["id"];
$elektronik = query("SELECT * FROM elektronik WHERE id = $id")[0];

if (isset($_POST["ubah"])) {
	if (ubah($_POST) > 0) {
		echo "<script>
			alert('Data Berhasil Diubah!');
			document.location.href = 'admin/index.php';
		</script>";
	} else {
		echo "<script>
			alert('Data Gagal Diubah!');
			
		</script>";
	}
	
}
 ?>
<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <title>Ubah Alat Elektronik</title>
 	<style>
 		body{
				background-color:#EF9835;
				color: #333;
				background-image: url(assets/img/dapur.png); 
			}

 		.container{
			font-family: Ink Free;
			font-weight: bold;

		}
 	</style>
    </head>

    <body>
    	 <div class="container">
    	 	<div class="row">	
    	 		<div class="card-panel #eeeeee grey lighten-3">
				 	<h2>Ubah Alat Elektronik</h2>
				 	
				 		
				 			<form action="" method="post" enctype="multipart/form-data">
				 				<input type="hidden" name="id" value="<?= $elektronik["id"]; ?>">
				 				<input type="hidden" name="gambarLama" value="<?= $elektronik["gambar"]; ?>">
					 				 <tr>
						 				<td>
									 		<label for="nama">Nama Alat Elektronik</label>
									 		<input type="text" name="nama" id="nama" autofocus="on" value="<?= $elektronik['nama']; ?>"> 
								 		</td>
								 	</tr>
							 		
							 		<tr>
								 		<td>
									 		<label for="gambar">Gambar</label><br><br>
									 		<img src="assets/img/<?= $elektronik['gambar']; ?>" width="200"><br>
									 		<input type="file" name="gambar" id="gambar" ><br>	
								 		</td>
								 	</tr>
							 		
							 		<tr>
								 		<td>
									 		<label for="fungsi">Fungsi</label>
									 		<input type="text" name="fungsi" id="fungsi" value="<?= $elektronik['fungsi']; ?>">
								 		</td>
								 	</tr>
							 		

							 		<tr>	
								 		<td>
									 		<label for="merk">Merk</label>
									 		<input type="text" name="merk" id="merk" value="<?= $elektronik['merk']; ?>">
								 		</td>
							 		</tr>

							 		<tr>	
								 		<td>
									 		<label for="harga">Harga</label>
									 		<input type="text" name="harga" id="harga" value="<?= $elektronik['harga']; ?>">
								 		</td>
								 	</tr>
							 		

							 		<tr>	
								 		<td>
									 		<button type="submit" name="ubah" id="submit" class="waves-effect waves-light btn brown lighten-2" >
									 			Ubah
									 		</button>

									 		<a href="admin/index.php" class="waves-effect waves-light btn brown lighten-2">
								 			kembali
								 			</a>
								 		</td>
								 	</tr>
							 		
				 			</form>
				 	</div>
			</div>
 </div>

      <!--JavaScript at end of body for optimized loading-->
      <script type="text/javascript" src="js/materialize.min.js"></script>
    </body>
  </html>

 

