<?php 

function koneksi()
{
	$conn = mysqli_connect("localhost", "root", "") or die("Koneksi Gagal!");
	mysqli_select_db($conn, "pw_183040085") or die("DB Salah!");

	return $conn;
}


function query($query) {
	$conn = koneksi();
	$results = mysqli_query($conn, $query);

	$rows = [];
	while( $row = mysqli_fetch_assoc($results) ) {
		$rows[] = $row;
	}
	return $rows;
}


function tambah($data)
{
	$conn = koneksi();

	$nama = htmlspecialchars($data['nama']);

	$fungsi = htmlspecialchars($data['fungsi']);
	$merk = htmlspecialchars($data['merk']);
	$harga = htmlspecialchars($data['harga']);

	//upload gambar
	$gambar = upload();
	if( !$gambar){
		return false;
	}

	$query_tambah = "INSERT INTO elektronik VALUES ('', '$nama', '$gambar', '$fungsi', '$merk', '$harga')";

	mysqli_query($conn, $query_tambah);
	
	return mysqli_affected_rows($conn);
}


function upload() {

	$namaFile = $_FILES['gambar']['name'];
	$ukuranFile = $_FILES['gambar']['size'];
	$error = $_FILES['gambar']['error'];
	$tmpName = $_FILES['gambar']['tmp_name'];

	// cek apakah tidak ada gambar yang diupload
	if( $error === 4 ) {
		echo "<script>
				alert('pilih gambar terlebih dahulu!');
			  </script>";
		return false;
	}

	// cek apakah yang diupload adalah gambar
	$ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
	$ekstensiGambar = explode('.', $namaFile);
	$ekstensiGambar = strtolower(end($ekstensiGambar));
	if( !in_array($ekstensiGambar, $ekstensiGambarValid) ) {
		echo "<script>
				alert('yang anda upload bukan gambar!');
			  </script>";
		return false;
	}

	// cek jika ukurannya terlalu besar
	if( $ukuranFile > 1000000 ) {
		echo "<script>
				alert('ukuran gambar terlalu besar!');
			  </script>";
		return false;
	}

	// lolos pengecekan, gambar siap diupload
	// generate nama gambar baru
	 $namaFileBaru  = uniqid();
	 $namaFileBaru .= '.';
	 $namaFileBaru .= $ekstensiGambar;

	 // var_dump($namaFileBaru); die;
	
	move_uploaded_file($tmpName, 'assets/img/'. $namaFileBaru);

	return $namaFileBaru;
}

function hapus($id){
	$conn = koneksi();
	mysqli_query($conn, "DELETE FROM elektronik WHERE id = $id");
	return mysqli_affected_rows($conn);
}

function ubah($data){
	$conn = koneksi();

	$id = $data['id'];
	// $id = htmlspecialchars($data['id']);
	$nama = htmlspecialchars($data['nama']);
	$gambarLama = htmlspecialchars($data['gambarLama']);

	// var_dump($gambarLama);die;
	// Cek apakah user pilih gambar baru apa engga
	if($_FILES['gambar']['error'] === 4 ) {
		$gambar = $gambarLama;
	} else {
		$gambar = upload();
	}

	
	$fungsi = htmlspecialchars($data['fungsi']);
	$merk = htmlspecialchars($data['merk']);
	$harga = htmlspecialchars($data['harga']);

	$query = " UPDATE elektronik SET nama = '$nama', gambar = '$gambar', fungsi = '$fungsi', merk = '$merk', harga = '$harga' WHERE id = '$id' ";
mysqli_query($conn, $query);
	
	return mysqli_affected_rows($conn);
$results = mysql_query($query) or die(mysql_error()); 

}


 ?>