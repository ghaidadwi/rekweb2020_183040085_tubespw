<?php 

if (!isset($_GET['id'])) {
	header("Location : index.php");
	exit;
}

require 'functions.php';
$id = $_GET['id'];

$e = query("SELECT * FROM elektronik WHERE id = $id")[0];

 ?>


 <!DOCTYPE html>
  <html>
    <head>
    	<title>Index Profil</title>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <style>
	      body{
				background-color:#EF9835;
				color: #333;
				background-image: url(assets/img/dapur.png); 
			}
		.gambar {
			width: 50px;
			height: 50px;
			
		}
		.kembali {
			font-family: Ink Free;
			font-weight: bolder;
			text-align: center;
			position: relative;
			top: 50px;
		}

		.kembali .in {
			text-decoration: none;
			color: #2F4F4F;
			font-weight: bolder;
			border:5px solid #9fa8da;
			border-radius: 10px;
		}

		.container {
			width: 400px;
		}
		h3 {
			text-align: center;
			font-family: Ink Free;
			font-weight: bolder;
			color: #4e342e;
		}
</style>
    </head>

    <body>
    	<!-- Profil card -->
    	<h3>Spesifikasi Alat Alat Elektronik</h3>
    	 <div>
              <div class="container">

                <div class="card hoverable">
                    <div class="card-image waves-effect waves-block waves-light">
                      <img class="activator" class ="gambar"src="assets/img/<?= $e["gambar"]; ?>">
                    </div>

                    <div class="card-content">
                      <span class="card-title activator indigo-text text-lighten-3"><?= $e['nama']; ?><i class="material-icons right">more_vert</i></span>
                    </div>

                      <div class="card-reveal">
                        <span class="card-title indigo-text text-lighten-3">Spesifikasi <i class="material-icons right">close</i></span>
                        <p><?= $e["fungsi"]; ?></p>
                        <p><?= $e["merk"]; ?></p>
                        <p><?= $e["harga"]; ?></p>
                        <p></p>
                      </div>  
                </div>

              </div>
             </div>
             		<div class='kembali'>
						<h5>
							<a class="waves-effect waves-light btn brown lighten-2"  href="index.php"><i class="material-icons left">undo</i>Kembali</a>
							
						</h5>
					</div>
    	<!-- TUTUP PRofil -->
      <script type="text/javascript" src="js/materialize.min.js"></script>
    </body>
  </html>
        

