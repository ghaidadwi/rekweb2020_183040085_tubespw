<?php 

require 'functions.php';

if (isset($_GET['cari'])) {
		$keyword = $_GET['search'];
		$elektronik = query("SELECT * FROM elektronik WHERE
			nama LIKE '%$keyword%' OR
			gambar LIKE '%$keyword%' OR
			fungsi LIKE '%keyword%' OR
			merk LIKE '%$keyword%' OR
			harga LIKE '%$keyword%' ");
	} else {
$elektronik = query("SELECT * FROM elektronik");

}

 ?>

 <!DOCTYPE html>
  <html>
    <head>
    	<title>index Halaman</title> 
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
      <script src="js/jquery-3.3.1.min.js"></script>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
       	<style>
		 	body{
			background-color:#EF9835;
			color: #333;
			background-image: url(assets/img/dapur.png); 
		}

 		.container1{
			width: 600px;
			margin: auto;
			border-radius: 10px;
			background-color: #d7ccc8  ;
			border: 1px solid #d7ccc8 ;
			box-shadow: 20px 20px 25px ;
			text-align: center;
			font-family: Ink Free;
			font-weight: bolder;
			font-size: 15px;
			
		}

		.container{
			margin: auto;
			font-family: Ink Free;
			font-weight: bolder;
			font-size: 15px;
		}

		.parallax img{
			width: 50px;
		}

		.gambar {
			width: 250px;
			height: 250px;
			border :1px solid white;
			border-radius: 200px;
		}
		.container1 a {
			text-align: center;
			color: #2F4F4F;
			font-weight: bolder;
			
			
		}

		h1 {
			text-align: center;
		}

		footer {
		padding: 20px 0px;
		}



		
		
</style>
    </head>

    <body id="home" >
    	<!-- Navbar -->
    	<div class="navbar-fixed">
	      <nav class="#d7ccc8 brown lighten-3">
	        <div class="container">
	         <div class="nav-wrapper">
	          <a href="#home" class="brand-logo center"><i class="material-icons">shopping_basket</i></a>
		         	</ul>
		            	<ul class="right hide-on-med-and-down">

	            		<li><a href="admin/Login.php" class="login" class="waves-effect waves-light btn" ><i class="material-icons right">desktop_mac</i>Login as Admin</a></li>
	           		 </ul>

			            <ul class="left hide-on-med-and-down">
			            	<li>	
			            	<form action="" method="get" >
			            	<i class="material-icons left">search
							<input  auto;" type="search" name="search" id="search" class="form-control" placeholder="Search..."></i>
							<button style="display: none;" type="submit" name="cari" id="cari" >cari</button>
							
							</form>
							</li>
						</ul>
            
		          </div>
		        </div>
		      </nav>
		      </div>
		      <!-- TUTUP NAVBAR -->

				      <!-- Parallax 1 -->

		      <div class="parallax-container valign-wrapper">
		    <div class="section ">
		      <div class="container">
		        <div class="row center">
		          <h1 class="header col s12 light white-text text-accent-1 ">Macam Macam Alat Elektronik</h1>
		        </div>
		      </div>
		    </div>
		    <div class="parallax"><img src="assets/img/hm.jpg"></div>
		  </div>
		        
		      <!-- Tutup Parallax 1 -->

      
     
      	
				<br><br>
				<!-- BOX -->
				
			      	 <div class="container1" >
					      
					      	 <?php if (empty($elektronik)) :?>
									 	<tr>
									 		<td colspan="8">
									 			<h4 align="center" class="data">Data Tidak Ditemukan!</h4>
									 		</td>
									 	</tr>
									 <?php else : ?>
					      	
								<?php foreach ($elektronik as $alat) : ?>
							        
							          <img class ="gambar"src="assets/img/<?php echo $alat["gambar"]; ?>">
								        
								          <p><?php echo $alat["fungsi"]; ?></p>
										   <div class="waves-effect waves-light btn #ffcdd2 red lighten-4"><a href="profil.php?id=<?=$alat['id']; ?>" ><?= $alat['nama'] ?></div></a>
							       <br><hr><br><hr>

						         <?php endforeach; ?>
								<?php endif ?>
					      
					   </div>
					
					   <br>
					   <br>
					 
			<!-- TUTUP BOX -->

			<!-- footer -->
				 <footer class="#d7ccc8 brown lighten-3 white-text center">
					<p class="flow-text">Ghaida Dwi Febriyanti. &copy right 2019</p>
				</footer>
			<!-- Tutup Footer -->

 			
				 <script type="text/javascript" src="js/materialize.min.js"></script>
				 <script>
				 	const parallax = document.querySelectorAll('.parallax');
	        		M.Parallax.init(parallax);

		        	
				 </script>
	    </body>
	  </html>
        


